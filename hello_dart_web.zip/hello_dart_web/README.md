# Getting Started

## Steps

1. Creating a new web app:

        dart create -t web-simple . --force

2. Installing webdev:

        dart pub global activate webdev

    Be sure to read the ouput then add **webdev** to PATH.

3. Serving the app:

        webdev serve

## References

- https://dart.dev/tutorials/web/get-started
- https://dart.dev/tools/webdev
